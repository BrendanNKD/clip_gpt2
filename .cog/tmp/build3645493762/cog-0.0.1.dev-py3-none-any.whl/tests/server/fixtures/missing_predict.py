class Predictor:
    def setup(self):
        print("did setup")

    # This predictor has no predict method
